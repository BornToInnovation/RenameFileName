package com.borntoinnovation.java.example;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class RenameFileName {
	static int totalNumberFilenameUpdate = 0;
	static int totalFileCount = 0;
	static boolean isUpdateFile = true;

	public static void updateFileName(String filePathURL, String oldFileName, String NewFileName) {
		List<String> fileList = new ArrayList<String>();

		try (Stream<Path> walk = Files.walk(Paths.get(filePathURL))) {
			fileList = walk.map(x -> x.toString()).collect(Collectors.toList());

			for (int i = 0; i < fileList.size(); i++) {
				Path path = Paths.get(fileList.get(i));
				if (path.getFileName().toString().toLowerCase().contains(oldFileName.toLowerCase())) {
					File file = new File(path.toString());
					if (file.isFile()) {
						totalFileCount++;
						int startIndex = path.getFileName().toString().toLowerCase()
								.lastIndexOf(oldFileName.toLowerCase());
						String fileName = path.getFileName().toString().substring(startIndex,
								path.getFileName().toString().length());
						boolean isFilenameReplace = file.renameTo(new File(path.toString().replace(fileName,
								NewFileName.concat(fileName.substring(oldFileName.length(), fileName.length())))));
						if (isFilenameReplace)
							totalNumberFilenameUpdate++;
						else
							System.out.println(path.getFileName());
					}
				}
			}
			System.out.println(totalNumberFilenameUpdate == 0 ? "File not found." : (totalNumberFilenameUpdate + " file updated successfully."));

		} catch (IOException e) {
			System.out.println("Invalid Path, Please enter valid path.");
		}
	}

	public static void main(String[] args) {
		String filePath = "C:\\Users\\BornToInnovation\\RenameFile";
		String oldFileName = "old_file";
		String NewFileName = "Update_file";
		updateFileName(filePath, oldFileName, NewFileName);
	}

}
